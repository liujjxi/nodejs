Express3 Demo
==============================

Nodejs给Javascript赋予了服务端应用的生命，Jquery让Javascript成为浏览中开发的利器。 最近学习了Nodejs的Express3.0的开发框架，本来是按照“node.js开发指南”书中介绍，但“node.js开发指南”讲的是Express2.x的，从Express2.x到Express3.0自己模索中还是走了不少弯路的。写篇文章总结一下。

项目分支
------------------------

+ Express 3.x Demo ( https://github.com/bsspirit/nodejs-demo/tree/express3 )
+ Express 4.x Demo ( https://github.com/bsspirit/nodejs-demo/tree/express4 )

关于作者
----------------------

* 张丹(Conan), 程序员Java,R,PHP,Javacript
* weibo：@Conan_Z
* blog: http://blog.fens.me
* email: bsspirit@gmail.com

使用说明
----------------------

Nodejs开发框架Express3.0开发手记–从零开始

http://blog.fens.me/nodejs-express3/ 

Mongoose使用案例：让JSON数据直接POST入MongoDB

http://blog.fens.me/nodejs-mongoose-json/ 

源代码下载
----------------------

程序代码已经上传到github有需要的同学，自行下载。
https://github.com/bsspirit/nodejs-demo
